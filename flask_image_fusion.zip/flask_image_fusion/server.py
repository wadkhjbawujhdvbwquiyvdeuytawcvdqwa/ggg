from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import cv2
import numpy as np
import os
import uuid
from werkzeug.utils import secure_filename
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

# 初始化Flask应用
app = Flask(__name__)
CORS(app)  # 允许跨域

# 配置文件夹
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB限制


# 根路由，提供index.html页面
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')


# ----------------- 核心算法函数 -----------------
def compute_contrast(image):
    """计算图像对比度"""
    mean = np.mean(image)
    return np.mean((image - mean) ** 2)


def contrast_based_fusion(infrared, visible):
    """基于对比度的图像融合"""
    infrared = cv2.resize(infrared, (visible.shape[1], visible.shape[0]))
    infrared_3c = cv2.cvtColor(infrared, cv2.COLOR_GRAY2BGR)

    # 计算权重
    w_ir = compute_contrast(infrared)
    w_vis = compute_contrast(cv2.cvtColor(visible, cv2.COLOR_BGR2GRAY))
    weight_ir = w_ir / (w_ir + w_vis)

    # 加权融合
    return cv2.addWeighted(infrared_3c, weight_ir, visible, 1 - weight_ir, 0)


def pyramid_fusion(infrared, visible, levels=4):
    # 确保两个图像尺寸相同
    if infrared.shape[:2] != visible.shape[:2]:
        infrared = cv2.resize(infrared, (visible.shape[1], visible.shape[0]))
    if len(infrared.shape) == 2:
        infrared = cv2.cvtColor(infrared, cv2.COLOR_GRAY2BGR)
    ir = infrared.astype(np.float32) / 255
    vis = visible.astype(np.float32) / 255
    h, w = ir.shape[:2]
    new_h, new_w = h, w
    if h % (2 ** levels) != 0:
        new_h = (h // (2 ** levels)) * (2 ** levels)
    if w % (2 ** levels) != 0:
        new_w = (w // (2 ** levels)) * (2 ** levels)
    if new_h != h or new_w != w:
        ir = cv2.resize(ir, (new_w, new_h))
        vis = cv2.resize(vis, (new_w, new_h))
    # 生成高斯金字塔
    ir_pyr = [ir]
    vis_pyr = [vis]
    for i in range(levels):
        ir_pyr.append(cv2.pyrDown(ir_pyr[i]))
        vis_pyr.append(cv2.pyrDown(vis_pyr[i]))
    # 生成拉普拉斯金字塔
    ir_lap_pyr = []
    vis_lap_pyr = []
    for i in range(levels):
        # 计算正确的上采样尺寸
        up_h, up_w = ir_pyr[i].shape[:2]
        # 确保尺寸是有效的(上采样后的尺寸应该是下一层尺寸的2倍或2倍-1)
        ir_up = cv2.pyrUp(ir_pyr[i + 1], dstsize=(up_w, up_h))
        vis_up = cv2.pyrUp(vis_pyr[i + 1], dstsize=(up_w, up_h))

        # 计算拉普拉斯差异
        ir_lap_pyr.append(ir_pyr[i] - ir_up)
        vis_lap_pyr.append(vis_pyr[i] - vis_up)

    # 添加最底层的高斯金字塔残差
    ir_lap_pyr.append(ir_pyr[-1])
    vis_lap_pyr.append(vis_pyr[-1])

    # 融合金字塔
    fused_lap_pyr = []
    for ir_lap, vis_lap in zip(ir_lap_pyr, vis_lap_pyr):
        # 根据对比度和显著性计算权重
        if len(ir_lap.shape) == 3:
            ir_gray = cv2.cvtColor(ir_lap, cv2.COLOR_BGR2GRAY)
            vis_gray = cv2.cvtColor(vis_lap, cv2.COLOR_BGR2GRAY)
        else:
            ir_gray = ir_lap
            vis_gray = vis_lap

        ir_contrast = cv2.GaussianBlur(np.abs(ir_gray), (5, 5), 0)
        vis_contrast = cv2.GaussianBlur(np.abs(vis_gray), (5, 5), 0)

        # 权重归一化
        weight_sum = ir_contrast + vis_contrast + 1e-10  # 防止除零
        ir_weight = ir_contrast / weight_sum

        # 逐通道融合
        fused_lap = np.zeros_like(ir_lap)
        if len(ir_lap.shape) == 3:
            for c in range(ir_lap.shape[2]):
                fused_lap[:, :, c] = ir_weight * ir_lap[:, :, c] + (1 - ir_weight) * vis_lap[:, :, c]
        else:
            fused_lap = ir_weight * ir_lap + (1 - ir_weight) * vis_lap

        fused_lap_pyr.append(fused_lap)

    # 重建融合图像
    fused = fused_lap_pyr[-1]  # 从最底层开始
    for i in range(levels - 1, -1, -1):
        up_h, up_w = fused_lap_pyr[i].shape[:2]
        fused = cv2.pyrUp(fused, dstsize=(up_w, up_h)) + fused_lap_pyr[i]

    # 裁剪到[0, 1]范围并转换为8位图像
    fused = np.clip(fused, 0, 1)
    # 恢复原始尺寸
    if new_h != h or new_w != w:
        fused = cv2.resize(fused, (w, h))

    return (fused * 255).astype(np.uint8)


def transformer_fusion(infrared, visible, patch_size=16, head_dim=32):
    """基于Transformer注意力机制的图像融合

    Args:
        infrared: 红外图像
        visible: 可见光图像
        patch_size: 图像块大小
        head_dim: 注意力头维度

    Returns:
        融合后的图像
    """
    # 确保两个图像尺寸相同
    if infrared.shape[:2] != visible.shape[:2]:
        infrared = cv2.resize(infrared, (visible.shape[1], visible.shape[0]))

    # 如果红外图像是单通道，转换为三通道
    if len(infrared.shape) == 2:
        infrared = cv2.cvtColor(infrared, cv2.COLOR_GRAY2BGR)

    # 转换为float32
    ir = infrared.astype(np.float32) / 255.0
    vis = visible.astype(np.float32) / 255.0

    # 获取图像尺寸
    h, w = ir.shape[:2]

    # 调整尺寸为patch_size的整数倍
    pad_h = (patch_size - h % patch_size) % patch_size
    pad_w = (patch_size - w % patch_size) % patch_size

    if pad_h > 0 or pad_w > 0:
        ir = cv2.copyMakeBorder(ir, 0, pad_h, 0, pad_w, cv2.BORDER_REFLECT)
        vis = cv2.copyMakeBorder(vis, 0, pad_h, 0, pad_w, cv2.BORDER_REFLECT)

    # 更新尺寸
    h, w = ir.shape[:2]

    # 计算每个通道的特征图
    fused_img = np.zeros_like(ir)

    for c in range(3):  # 对每个通道分别处理
        ir_c = ir[:, :, c]
        vis_c = vis[:, :, c]

        # 提取特征 - 简化版本的特征提取
        ir_grad_x = cv2.Sobel(ir_c, cv2.CV_32F, 1, 0, ksize=3)
        ir_grad_y = cv2.Sobel(ir_c, cv2.CV_32F, 0, 1, ksize=3)
        vis_grad_x = cv2.Sobel(vis_c, cv2.CV_32F, 1, 0, ksize=3)
        vis_grad_y = cv2.Sobel(vis_c, cv2.CV_32F, 0, 1, ksize=3)

        ir_grad = np.sqrt(ir_grad_x ** 2 + ir_grad_y ** 2)
        vis_grad = np.sqrt(vis_grad_x ** 2 + vis_grad_y ** 2)

        # 注意力权重计算 - 模拟Transformer的注意力机制
        # 将图像分成小块，计算每个区域的重要性
        num_h_patches = h // patch_size
        num_w_patches = w // patch_size

        for i in range(num_h_patches):
            for j in range(num_w_patches):
                # 获取当前patch
                h_start, h_end = i * patch_size, (i + 1) * patch_size
                w_start, w_end = j * patch_size, (j + 1) * patch_size

                # 提取当前patch
                ir_patch = ir_grad[h_start:h_end, w_start:w_end]
                vis_patch = vis_grad[h_start:h_end, w_start:w_end]

                # 计算patch内的平均梯度 (特征激活强度)
                ir_activation = np.mean(ir_patch)
                vis_activation = np.mean(vis_patch)

                # 使用softmax计算注意力权重 (模拟自注意力机制)
                ir_weight = np.exp(ir_activation)
                vis_weight = np.exp(vis_activation)
                sum_weights = ir_weight + vis_weight

                ir_attention = ir_weight / sum_weights
                vis_attention = vis_weight / sum_weights

                # 融合当前patch
                ir_content = ir_c[h_start:h_end, w_start:w_end]
                vis_content = vis_c[h_start:h_end, w_start:w_end]

                # 自适应融合 (类似于多头注意力的聚合)
                fused_patch = ir_attention * ir_content + vis_attention * vis_content

                # 保存融合结果
                fused_img[h_start:h_end, w_start:w_end, c] = fused_patch

    # 应用边缘保持滤波器增强细节
    fused_img = cv2.detailEnhance(fused_img, sigma_s=10, sigma_r=0.15)

    # 裁剪到原始尺寸并转换为8位图像
    if pad_h > 0 or pad_w > 0:
        fused_img = fused_img[:h - pad_h, :w - pad_w]

    # 裁剪到[0, 1]范围
    fused_img = np.clip(fused_img, 0, 1)

    return (fused_img * 255).astype(np.uint8)


def autoencoder_fusion(infrared, visible, n_components=20, patch_size=8):
    """基于自编码器(AE)的图像融合方法

    Args:
        infrared: 红外图像
        visible: 可见光图像
        n_components: PCA组件数量(模拟编码维度)
        patch_size: 图像块大小

    Returns:
        融合后的图像
    """
    # 确保两个图像尺寸相同
    if infrared.shape[:2] != visible.shape[:2]:
        infrared = cv2.resize(infrared, (visible.shape[1], visible.shape[0]))

    # 如果红外图像是单通道，转换为三通道
    if len(infrared.shape) == 2:
        infrared = cv2.cvtColor(infrared, cv2.COLOR_GRAY2BGR)

    # 转换为float32
    ir = infrared.astype(np.float32) / 255.0
    vis = visible.astype(np.float32) / 255.0

    # 获取图像尺寸
    h, w = ir.shape[:2]

    # 调整尺寸为patch_size的整数倍
    pad_h = (patch_size - h % patch_size) % patch_size
    pad_w = (patch_size - w % patch_size) % patch_size

    if pad_h > 0 or pad_w > 0:
        ir = cv2.copyMakeBorder(ir, 0, pad_h, 0, pad_w, cv2.BORDER_REFLECT)
        vis = cv2.copyMakeBorder(vis, 0, pad_h, 0, pad_w, cv2.BORDER_REFLECT)

    # 更新尺寸
    h, w = ir.shape[:2]

    # 计算每个通道的特征图
    fused_img = np.zeros_like(ir)

    for c in range(3):  # 对每个通道分别处理
        # 提取当前通道
        ir_c = ir[:, :, c]
        vis_c = vis[:, :, c]

        # 计算局部特征
        ir_features = []
        vis_features = []

        # 分块处理图像
        for i in range(0, h - patch_size + 1, patch_size // 2):
            for j in range(0, w - patch_size + 1, patch_size // 2):
                ir_patch = ir_c[i:i + patch_size, j:j + patch_size].flatten()
                vis_patch = vis_c[i:i + patch_size, j:j + patch_size].flatten()

                ir_features.append(ir_patch)
                vis_features.append(vis_patch)

        ir_features = np.array(ir_features)
        vis_features = np.array(vis_features)

        # 使用PCA模拟自编码器的编码过程
        from sklearn.decomposition import PCA

        # 确保n_components不超过特征维度
        n_comp = min(n_components, ir_features.shape[1], ir_features.shape[0])

        # 应用PCA降维 (编码)
        pca_ir = PCA(n_components=n_comp)
        pca_vis = PCA(n_components=n_comp)

        # 拟合并转换
        ir_encoded = pca_ir.fit_transform(ir_features)
        vis_encoded = pca_vis.fit_transform(vis_features)

        # 计算特征激活强度
        ir_activation = np.mean(np.abs(ir_encoded), axis=1)
        vis_activation = np.mean(np.abs(vis_encoded), axis=1)

        # 归一化激活值
        total_activation = ir_activation + vis_activation + 1e-10
        ir_weights = ir_activation / total_activation
        vis_weights = vis_activation / total_activation

        # 特征加权融合
        fused_encoded = np.zeros_like(ir_encoded)
        for i in range(len(ir_encoded)):
            fused_encoded[i] = ir_weights[i] * ir_encoded[i] + vis_weights[i] * vis_encoded[i]

        # 重构 (解码)
        ir_decoded = pca_ir.inverse_transform(fused_encoded)
        vis_decoded = pca_vis.inverse_transform(fused_encoded)

        # 结合两个重构结果
        decoded = (ir_decoded + vis_decoded) / 2

        # 重构融合图像
        fused_c = np.zeros_like(ir_c)
        count = np.zeros_like(ir_c)

        # 重叠块的平均值
        idx = 0
        for i in range(0, h - patch_size + 1, patch_size // 2):
            for j in range(0, w - patch_size + 1, patch_size // 2):
                patch = decoded[idx].reshape((patch_size, patch_size))
                fused_c[i:i + patch_size, j:j + patch_size] += patch
                count[i:i + patch_size, j:j + patch_size] += 1
                idx += 1

        # 避免除零
        count[count == 0] = 1
        fused_c /= count
        fused_img[:, :, c] = fused_c

    # 增强边缘细节
    fused_img = cv2.detailEnhance(fused_img, sigma_s=10, sigma_r=0.15)

    # 裁剪到原始尺寸
    if pad_h > 0 or pad_w > 0:
        fused_img = fused_img[:h - pad_h, :w - pad_w]

    # 确保值在[0,1]范围内
    fused_img = np.clip(fused_img, 0, 1)
    return (fused_img * 255).astype(np.uint8)


def rgb_to_ir(visible_img, mode='advanced'):
    """可见光转红外 (支持基础/高级模式)"""
    if mode == 'basic':
        # 基础方法：提取红色通道
        _, _, r = cv2.split(visible_img)
        return cv2.normalize(r, None, 0, 255, cv2.NORM_MINMAX)
    else:
        # 高级方法：HSV空间处理
        hsv = cv2.cvtColor(visible_img, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(hsv)

        # 增强红黄区域，减弱蓝绿区域
        v[(h < 15) | (h > 165)] = np.clip(v[(h < 15) | (h > 165)] * 1.3, 0, 255)  # 红色
        v[(h > 15) & (h < 45)] = np.clip(v[(h > 15) & (h < 45)] * 1.2, 0, 255)  # 黄色
        v[(h > 90) & (h < 130)] = np.clip(v[(h > 90) & (h < 130)] * 0.7, 0, 255)  # 蓝色

        enhanced = cv2.merge([h, s, v.astype(np.uint8)])
        gray = cv2.cvtColor(cv2.cvtColor(enhanced, cv2.COLOR_HSV2BGR), cv2.COLOR_BGR2GRAY)
        return cv2.equalizeHist(gray)


# ----------------- API路由 -----------------
@app.route('/api/upload', methods=['POST'])
def handle_fusion():
    """处理图像融合请求"""
    try:
        ir_file = request.files['infrared']
        vis_file = request.files['visible']
        fusion_method = request.form.get('method', 'pyramid')  # 默认使用金字塔融合

        # 保存文件
        process_id = str(uuid.uuid4())
        ir_path = os.path.join(UPLOAD_FOLDER, f"{process_id}_ir.jpg")
        vis_path = os.path.join(UPLOAD_FOLDER, f"{process_id}_vis.jpg")
        ir_file.save(ir_path)
        vis_file.save(vis_path)

        # 读取图像
        ir_img = cv2.imread(ir_path, cv2.IMREAD_GRAYSCALE)
        vis_img = cv2.imread(vis_path)

        # 选择融合方法
        if fusion_method == 'contrast':
            fused = contrast_based_fusion(ir_img, vis_img)
        elif fusion_method == 'transformer':
            fused = transformer_fusion(ir_img, vis_img)
        elif fusion_method == 'autoencoder':
            fused = autoencoder_fusion(ir_img, vis_img)
        else:
            fused = pyramid_fusion(ir_img, vis_img, levels=4)

        # 保存结果
        result_path = os.path.join(RESULT_FOLDER, f"{process_id}_fused.jpg")
        cv2.imwrite(result_path, fused)

        return jsonify({
            'success': True,
            'result_url': f'/api/results/{process_id}_fused.jpg'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/convert_to_ir', methods=['POST'])
def handle_conversion():
    """处理可见光转红外请求"""
    try:
        vis_file = request.files['visible']
        process_id = str(uuid.uuid4())
        vis_path = os.path.join(UPLOAD_FOLDER, f"{process_id}_vis.jpg")
        vis_file.save(vis_path)

        # 转换图像
        ir_simulated = rgb_to_ir(cv2.imread(vis_path))
        result_path = os.path.join(RESULT_FOLDER, f"{process_id}_ir.jpg")
        cv2.imwrite(result_path, ir_simulated)

        return jsonify({
            'success': True,
            'result_url': f'/api/results/{process_id}_ir.jpg'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/results/<filename>')
def serve_result(filename):
    """返回处理结果图像"""
    return send_from_directory(RESULT_FOLDER, filename)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)